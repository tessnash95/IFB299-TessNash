<?php

define ('__FILE__', null);
define ('__LINE__', null);
define ('__CLASS__', null);
define ('__FUNCTION__', null);
define ('__METHOD__', null);
define ('__DIR__', null);
define ('__NAMESPACE__', null);
