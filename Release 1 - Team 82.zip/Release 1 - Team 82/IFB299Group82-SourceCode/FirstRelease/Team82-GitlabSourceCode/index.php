<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: index.php
File Version: 1.0.2 (Release.ConfirmedVersion.CurrentVersion) 
Author: Ji-Young Choi


---------------------------------------------------------
				Updates
Version: 1.0.1 (Ji-Young Choi)

Intial Issue

Version: 1.0.2 (Se Jun Ahn)

Formatting page.

---------------------------------------------------------

Description of the page: just located into index.php page in directory as we are working on local host.

--------------------------------------------------------->

<!-- connect to index.php file in pages directory. -->

<?php
 header("location: pages/index.php");
?>
