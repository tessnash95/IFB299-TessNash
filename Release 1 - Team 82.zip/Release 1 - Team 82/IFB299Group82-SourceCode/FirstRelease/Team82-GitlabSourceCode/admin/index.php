<!-------------------------------------------------------

Subject: IFB299 Group: Group 82
Webpage: index.php(admin directory)
File Version: 1.0.2 (Release.ConfirmedVersion.CurrentVersion)
Author: Ji-Young Choi

---------------------------------------------------------
Updates
Version: 1.0.1 (Ji-Young Choi)

Intial Issue

Version: 1.0.2 (Se Jun Ahn)

Formatting page.

---------------------------------------------------------

Description of the page: Index page for admin.
--------------------------------------------------------->
<?php
 $page = "admin - Home";
 include '../includes/connect.php';
 include '../admin/header.php';
 include 'adminnav.php';
 include '../includes/logincheckadmin.php';
?>

	<div class="container">
	<hr>
 	<h2>Content Management System</h2>
	<hr>
 		<?php
 			$sql = "SELECT (SELECT COUNT(*) FROM events) AS 'totalevents', (SELECT
			SUM(donationMoney) FROM fundedMoney) AS 'totalfunding', (SELECT COUNT(*) FROM member) AS
			totalmembers";
 			$result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
			while ($row = mysqli_fetch_array($result))
			{
				echo "<table>";
				echo "<th colspan='2'>status</th>";
				echo "<tr>";
				echo "<td>" . $row['totalevents'] . "</td><td> Total events</td>";
				echo "</tr>";
				echo "<tr>";
				echo "<td>" . $row['totalmembers'] . "</td><td> Total members</td>";
				echo "</tr>";

				echo "<tr >";
				echo "<td>" . $row['totalfunding'] . "</td><td> TotaldonationMoney </td>";
 				echo "</tr>";
 				echo "</table>";
 			}
 		?>
	</div> <!-- end content -->

<?php
 include '../includes/footer.php';
?>
