<!-------------------------------------------------------

Subject: IFB299 Group: Group 82
Webpage: memberdelete.php
File Version: 1.0.2 (Release.ConfirmedVersion.CurrentVersion)
Author: Ji-Young Choi

---------------------------------------------------------
Updates
Version: 1.0.1 (Ji-Young Choi)

Intial Issue

Version: 1.0.2 (Se Jun Ahn)

Formatting page.

---------------------------------------------------------

Description of the page: Function to delete member through email verification.
--------------------------------------------------------->
<?php
	session_start();
	include"../includes/connect.php";
?>

<?php
	$memberID=$_GET['memberID'];
	$sql = "SELECT * FROM member WHERE memberID = '$memberID' and memberdelete= '1' ";
	$result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
	$row = mysqli_fetch_array($result); //create a variable called '$row' to store the results
	$count=mysqli_num_rows($result);
	$result=mysqli_query($con,$sql)or die(($con));
	
	if($count==1)
	{
		require 'PHPMailerAutoload.php';
 		$mail = new PHPMailer();
 		$mail->CharSet =  "utf-8";
 		$mail->IsSMTP();
 // enable SMTP authentication
		$mail->SMTPAuth = true;
 // GMAIL username
		$mail->Username = "community82.ifb299@gmail.com";
 // GMAIL password
		$mail->Password = "adminpassword123";
 		$mail->SMTPSecure = "ssl";
 // sets GMAIL as the SMTP server
 		$mail->Host = "smtp.gmail.com";
 // set the SMTP port for the GMAIL server
 		$mail->Port = "465";
 		$mail->From='community82.ifb299@gmail.com';
 		$mail->FromName='community';
 		$mail->AddAddress($row['email'] , $username);
 		$mail->Subject  =  ' your accoout has been deleted at community82';
 		$mail->IsHTML(true);
 		$mail->Body    = 'your account has been deleted at community82';

 		if($mail->Send())
 		{
   			$sql="DELETE member.* FROM member WHERE memberID = '$memberID'";
   			$result=mysqli_query($con,$sql)or die(($con));
   			$_SESSION['success']='member deleted successfully.';
  			header('location: membermanage.php');
		}
//register a session witha success message
	}
	else
	{
		$_SESSION['error']='member did not apply delete account';
		header('location: membermanage.php');
	}
?>
