<!-------------------------------------------------------

Subject: IFB299 Group: Group 82
Webpage: eventupdateprocessing.php
File Version: 1.0.2 (Release.ConfirmedVersion.CurrentVersion)
Author: Ji-Young Choi

---------------------------------------------------------
Updates
Version: 1.0.1 (Ji-Young Choi)

Intial Issue

Version: 1.0.2 (Se Jun Ahn)

Formatting page.

---------------------------------------------------------

Description of the page: function to update events.
--------------------------------------------------------->

<?php
 session_start();
 include "../includes/connect.php";
?>

<?php
 $eventID = $_POST['eventID']; //retrieve reviewID from hidden form field

 $title = mysqli_real_escape_string($con, $_POST['title']); //prevent SQL injection
 $content = mysqli_real_escape_string($con, $_POST['content']);
 $venue = mysqli_real_escape_string($con, $_POST['venue']);
 $eventdate = mysqli_real_escape_string($con, $_POST['eventdate']);
 $adminID = mysqli_real_escape_string($con, $_POST['adminID']);

 $sql="UPDATE events SET title='$title', content='$content',venue='$venue',eventdate='$eventdate' ,adminID= '$adminID' WHERE eventID ='$eventID'";
 $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

 $_SESSION['msg'] = 'event updated successfully'; //if category update is successful intialise a session called 'success' with a msg
 header("location:commitindex.php"); //redirect to categoryupdate.php
?>
