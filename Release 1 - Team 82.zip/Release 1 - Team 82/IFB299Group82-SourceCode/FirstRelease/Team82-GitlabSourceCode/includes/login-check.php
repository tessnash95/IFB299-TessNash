
<?php
 if (!isset($_SESSION['login']))
 {
 header('location:index.php');
 }else{
 echo "<li>"."Welcome&nbsp&nbsp" . $_SESSION['login'] ." </li>";
 }
?>
