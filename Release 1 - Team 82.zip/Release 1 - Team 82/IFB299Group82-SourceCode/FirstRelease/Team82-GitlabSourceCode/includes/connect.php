<?php
 $con = mysqli_connect("localhost", "EventAdmin", "password123", "community");
 
 if (mysqli_connect_errno($con))
 {
 echo "Unable to connect to the server: " . mysqli_connect_error();
 exit();
 }
?>
