
<div class="container">

<div class="row">


    <div class="col-md-offset-1 col-md-2 ">
  <h3 class ="ugent"><u style="color:#FF5733;"><span style="color:#000;"><strong>U</strong></span></u>rgent Cause</h3>
         <img src="../img/urgent1.jpg" alt="urgent" style="width:300px; " class="img-responsive" >
</div>

  <div class="col-md-4" style="margin-top:25px;">

          <?php
          $sql = "SELECT * FROM donation" ;
          $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
          while ($row = mysqli_fetch_array($result)){
          echo  '<h4><strong ">'.$row['donationTitle'].'</strong></h4>';
          echo '<span style="color:#FF5733;font-size:2rem;">'.$row['donationDes'].'</span>';

        }
  ?>
        <div class="table-responsive">
      <table class="table">
      <thead>
       <tbody>
  <?php
        $sql = "SELECT SUM(donationMoney) , goalMoney FROM fundedmoney, donation";
        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query


        while ($row = mysqli_fetch_assoc($result)){

        $percent = $row['SUM(donationMoney)']/$row['goalMoney']*100 ;
        echo "<tr><th> Donaters - </th><td>3</td></tr>";
        echo "<tr><th> Goal -</th><td> $". $row['goalMoney'].'</td></tr>';
        echo "<tr><th> Raised -</th><td> $". $row['SUM(donationMoney)'].'</td></tr> </thead></tbody></table>
       </div>';
        echo '<div class="rating"><div class="graphcont"><div class="graph"><strong class="bar" style="width:'.round($percent).'%;"><span class="one">'. round($percent).'%</strong></span></div></div></div>';
        }
    ?>
<div style="float:left;">
  <h4>Lorem Ipsum is simply dummy text of the</h4></div>
  <button type="button" class="btn btn-default boxbtn" style="background-color:#0066FF; border:3px solid #0066FF; color:#fff; margin-top:5px;"> DONATE</button>
  <button type="button" class="btn btn-default boxbtn" style="border:3px solid #0066FF; color:#0066FF; margin-top:5px;" >READ MORE</button>
</div>






    <div class="col-md-4  ">
  <h3 class ="ugent"><u style="color:#FF5733;"><span style="color:#000;"><strong>U</strong></span></u>pcoming events</h3>
      <div class="media"><div class="media-left media-middle"><a href="eventpost.php?eventID=4"><img class="media-object" src="../img/test4.jpg"  width="100px"height="66px" alt="..."></a></div><div class="media-body"><h5 class="media-heading "><strong>WATER OF LIFE</strong> <span class="pull-right eventdatebtn2"> 24 Sep</h5></span><h5>Botanic garden </h5></div></div><hr margin-top='2px'><div class="media"><div class="media-left media-middle"><a href="eventpost.php?eventID=3"><img class="media-object" src="../img/test1.jpg"  width="100px"height="66px" alt="..."></a></div><div class="media-body"><h5 class="media-heading "><strong>HEALING THROUGH ARTddqt</strong> <span class="pull-right eventdatebtn2"> 30 Sep</h5></span><h5>QUTd </h5></div></div><hr margin-top='2px'>         
      
      
  </div>    
  </div>    
    <br>    
      
      
      
    <div class="container-fluid text-center bg-grey" >    
      <div class="col-sm-4">    
      
        <div class="thumbnail"><p class=" text-center"><strong><span style="font-size:1.8em;">Donation</span></strong><br>    
          Ytdsffdlkjfdsalkfdsa<br>lkfdaslkfdsalkfafd</p>    
          <img src="../img/donation1.jpg" alt="Paris" width="230" height="200">   
      
        </div><button type="button" class="btn btn-default boxbtn" href ="donation.php" > <span class="glyphicon glyphicon-triangle-right" aria-hidden="true"></span>DONATE NOW</button>    
      </div>    
      <div class="col-sm-4">    
      
        <div class="thumbnail" style="background-color:#FF5733;"><p><strong><span style="font-size:1.8em;">Volunteer</span></strong><br>    
          Ytdsffdlkjfdsalkfdsa<br>lkfdaslkfdsalkfafd</p>    
          <img src="../img/donation1.jpg" alt="Paris" width="230" height="200">   
      
        </div><button type="button" class="btn btn-default boxbtn" href ="volregi.php"style="background-color:#000; border:#000; color:#fff;"> <span class="glyphicon glyphicon-triangle-right" aria-hidden="true"></span>JOIN NOW</button>   
      </div>    
      <div class="col-sm-4">    
      
        <div class="thumbnail"><p><strong><span style="font-size:1.8em;">Event</span></strong><br>    
          Ytdsffdlkjfdsalkfdsa<br>lkfdaslkfdsalkfafd</p>    
          <img src="../img/donation1.jpg" alt="Paris" width="230" height="200">   
      
        </div> <button type="button" href ="event.php" class="btn btn-default boxbtn"> <span class="glyphicon glyphicon-triangle-right" aria-hidden="true"></span>READ MORE</button>    
      </div>    
      
      </div>    
      
      
  </div>