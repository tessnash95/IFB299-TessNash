
<nav class="navbar navbar-fixed-top">

  <div class="container-fluid" style="padding-left:0";>
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>


    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-left">

        <li class="joincolor" style="padding-left:0"><a href="../pages/regichoice.php"> Join us</a></li>
        <li ><a <?php if($page=='Home'){echo "class='active'";} ?>
        href="index.php">Home</a></li>
       <li><a <?php if($page=='About'){echo "class='current'";} ?>
        href="about.php">About</a></li>
      <li><a <?php if($page=='Event'){echo "class='current'";} ?>
        href="event.php">Events</a></li>
        <li><a <?php if($page=='Volunteer'){echo "class='current'";} ?>
        href="volregi.php">Volunteer</a></li>
      <li><a <?php if($page=='Say Hello'){echo "class='current'";} ?>
        href="contact.php">Contact</a></li>

   </ul>



<?php
 if((isset($_SESSION['member'])) ) // check to see if a member or admin is logged in and, if so, display the logged in menu items
 {
?>
<ul class="nav navbar-nav navbar-right">
<?php echo  "<span class='name'><li>"."Welcome&nbsp&nbsp" .($_SESSION['member'])." </li></span>";?>
<li><a <?php if($page=='memberaccount'){echo "class='current'";} ?> href="memberlanding.php">My Account</a></li>
<li><a  href="logout.php">Logout</a></li>




<?php
}
elseif((isset($_SESSION['volunteer'])) )  //if a member or admin is not logged in display the not logged in menu items
{
?>
<ul class="nav navbar-nav navbar-right">
<?php echo  "<span class='name'><li>"."Welcome&nbsp&nbsp" .($_SESSION['volunteer'])." </li></span>";?>
<li><a <?php if($page=='volunteeraccount'){echo "class='current'";} ?>href="vollogined.php">My Account</a></li>
<li><a href="logout.php">Logout</a></li>


 <!-- end registration -->

<?php
}
?>
<ul class="nav navbar-nav navbar-right clander">

<li><a href="#"><i class="fa fa-calendar fa-lg" style="color:#fff; float:left;"></i></a><li>
</nav>
