<?php
include"../includes/connect.php";?>
<?php
if(!isset($_SESSION['admin']))
{
header('location:../index.php');
//if the'admin' session is not setredirect tothe front end index.php
}
?>
