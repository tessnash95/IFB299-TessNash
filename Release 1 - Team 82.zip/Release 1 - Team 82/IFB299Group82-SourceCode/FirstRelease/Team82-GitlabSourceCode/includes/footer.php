

<footer class="footer navbar-fixed-bottom">

&copy; copyright&nbsp;&#9615; WEBSITE BY community82 2016
<a href= "../admin/adminlogin.php">admin login</a>

</footer>
</body>


</html>
