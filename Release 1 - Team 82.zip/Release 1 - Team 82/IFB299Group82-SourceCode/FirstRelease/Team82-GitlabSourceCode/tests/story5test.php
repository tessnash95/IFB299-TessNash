<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: story5test
File Version: 1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: All members involved within the
company should be able to update their data all times.

--------------------------------------------------------->

<?php
use PHPUnit_Framework_TestCase;
include 'pages/accountpasswordprocessing';
require_once 'PHPUnit/Autoload.php';

/*
 * Description: this is the function to establish a connection to the mysql database
 *
 * output: returns the mysqli construct as an established connection
 *
 * */
function setUp()
{

	$con = mysqli_connect("localhost", "EventAdmin", "password123", "community");

	if (mysqli_connect_errno($con))
	{
		echo "Unable to connect to the server: " . mysqli_connect_error();
		exit();
	}

	return $con;
}

class story5test extends \PHPUnit_Framework_TestCase
{
	/*
	 * Description: this is the function to show if the salt column and if its string is random
	 *
	 *
	 * */
	/** @test */
	public function checkForSalting()
	{
		
		$con = setUp();

		$queryCheckSaltColumn = "SELECT salt FROM member";
		
		$result = mysqli_query($con, $queryCheckSaltColumn) or die(mysqli_error($con));
		
		$row = mysqli_fetch_array($result);
		
		$g = $row[0];
		
		echo $g;

		$this->assertNotNull($g);

	}
	

	/*
	 * Description: this is the function to show if the password column and if its string is random
	 *
	 *
	 * */
	/** @test */
	public function checkForPassword()
	{
		
		$con = setUp();
		
		$queryCheckSaltColumn = "SELECT password FROM member";
		
		$result = mysqli_query($con, $queryCheckSaltColumn) or die(mysqli_error($con));
		
		$row = mysqli_fetch_array($result);
		
		$g = $row[0];
		
		echo $g;
		
		$this->assertNotNull($g);

	}

	


}

?>