<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: Story8test
File Version: 1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: Events should be able made,
modified and deleted from the user that has activated 
the event protocol. Administrators can alter any 
event that is registered in the database.
--------------------------------------------------------->

<?php

/*
 * Description: Genererates a randomly generated string that at defualt starts at 10
 *
 * input: $length is the string size to be randomly generated where the default is
 * 		  set to 10
 * output: $randomString is the randomly generated string by the length of $length
 *
 * */
function generateRandomString($length = 10) {
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}

/*
 * Description: this is the function to establish a connection to the mysql database
 *
 * output: returns the mysqli construct as an established connection
 *
 * */
function setUp()
{

	$con = mysqli_connect("localhost", "EventAdmin", "password123", "community");

	if (mysqli_connect_errno($con))
	{
		echo "Unable to connect to the server: " . mysqli_connect_error();
		exit();
	}

	return $con;
}


class story8test extends \PHPUnit_Framework_TestCase
{
	
	/*
	 * Description: Tests whether events can be deleted or added
	 * 
	 */
	
	/** @test */
	public function eventNewandDeletetest(){
	
		echo "verifying that new events can be inserted\n";
	
		$con = setUp();
	
		$valueInsert = "INSERT INTO `events` (`eventID`, `title`, `content`, `categoryID`, `adminID`, `eventdate`, `venue`, `eventimg`, `memberID`) VALUES (8, 'ADOPT A CAT', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', 1, 2, '2016-09-21 14:00:00', 'city hall', 'test3.jpg', 1);";
	
		$insertvalue = mysqli_query($con, $valueInsert) or die(mysqli_error($con));
		
		echo "value is inserted\n";
	
		$checkValue = "select eventID FROM events WHERE eventID = '8';";
	
		$checkResult = mysqli_query($con, $checkValue) or die(mysqli_error($con));
		
		echo "checking if correct value is inserted\n";
	
		if ($checkResult = NULL)
		{
				
			$this->assertTrue(false);
		}
		else{
				
			$this->assertTrue(true);
		}
		
		echo "verifying that events can be deleted\n";
	
		$deleteValue = "DELETE from events WHERE eventID = '8';";
	
		$deleteResult = $checkResult = mysqli_query($con, $deleteValue) or die(mysqli_error($con));
	
		echo "value is deleted\n";
		
		$checkdelete = "select eventID FROM events WHERE eventID = '8';";
	
		$deleteResult = mysqli_query($con, $checkdelete) or die(mysqli_error($con));
		
		$row = mysqli_fetch_array($deleteResult);
		
		echo "checking if value still exists\n";
		
		echo $checkResult[0];
	
		if (!$row)
		{
	
			$this->assertTrue(true);
		}
		else{
	
			$this->assertTrue(false);
		}
	}
	
	/*
	 * Description: Tests whether events can be edited
	 */
	/** @test */
	public function eventupdateInformationtest(){
	
		echo "verifying the details can be updated table events\n";
	
		$con = setUp();
	
		$queryfirstEventTitle = "SELECT eventID FROM events ORDER BY eventID ASC LIMIT 1;";
	
		$originalResult = mysqli_query($con, $queryfirstEventTitle) or die(mysqli_error($con));
	
		$row1 = mysqli_fetch_array($originalResult);
	
		$g = $row1[0];
	
		echo "Event eventID where title will be changed: ";
	
		echo "'$row1[0]'\n";
	
		$newName = generateRandomString();
			
		echo "randomly generated string: ";
	
		echo "'$newName'\n";
	
		$queryAlterTableEventTitle = "UPDATE events SET title='$newName'  WHERE eventID='$g';";
	
		mysqli_query($con, $queryAlterTableEventTitle) or die(mysqli_error($con));
	
		$queryNewTitleName	 = "SELECT title FROM events WHERE title= '$newName';";
	
		$newResult = mysqli_query($con, $queryNewTitleName) or die(mysqli_error($con));
	
		$row2 = mysqli_fetch_array($newResult);
	
		echo "string in the event column: '$row2[0]'";
	
		$this->assertSame($row2[0], $newName);
	}
	
}

