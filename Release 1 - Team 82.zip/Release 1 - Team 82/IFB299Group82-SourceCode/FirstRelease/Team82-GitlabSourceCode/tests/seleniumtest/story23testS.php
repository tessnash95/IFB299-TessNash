<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: Story23testS
File Version:1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: That user information is protected 
from other users from altering their information and that 
administration can alter information that does not breach 
the Privacy Act 1998. 

--------------------------------------------------------->

<?php
class Example extends PHPUnit_Extensions_SeleniumTestCase
{
	protected function setUp()
	{
		$this->setBrowser("*chrome");
		$this->setBrowserUrl("http://gitlab.localhost/community3/community/pages/index.php");
	}

	public function testMyTestCase()
	{
		$this->open("/community4/FirstRelease/sorcecode/pages/index.php");
		$this->click("link=Login");
		$this->type("id=username", "admintest");
		$this->type("id=password", "12345678");
		$this->click("name=login");
		$this->waitForPageToLoad("30000");
		$this->click("link=Update");
		$this->waitForPageToLoad("30000");
		$this->type("name=contactnumber", "1234");
		$this->click("name=memberupdate");
		$this->waitForPageToLoad("30000");
		$this->click("link=Update");
		$this->waitForPageToLoad("30000");
		$this->type("name=contactnumber", "1233");
		$this->click("name=memberupdate");
		$this->waitForPageToLoad("30000");
		$this->click("link=member infomation /");
		$this->waitForPageToLoad("30000");
		$this->click("link=Logout/");
		$this->waitForPageToLoad("30000");
		$this->open("/community4/FirstRelease/sorcecode/pages/index.php");
		$this->open("/community4/FirstRelease/sorcecode/pages/admin/index.php");
		$this->open("/community4/FirstRelease/sorcecode/pages/admin/membermanage.php");
	}
}
?>