<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: Story8testS
File Version:1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: Events should be able made, 
modified and deleted from the user that has activated 
the event protocol. Administrators can alter any event 
that is registered in the database.
--------------------------------------------------------->
<?php
class Example extends PHPUnit_Extensions_SeleniumTestCase
{
  protected function setUp()
  {
    $this->setBrowser("*chrome");
    $this->setBrowserUrl("http://54.206.25.253/");
  }

  public function testMyTestCase()
  {
    $this->open("/pages/index.php");
    $this->click("link=Login");
    $this->type("id=username", "vol1");
    $this->type("id=password", "12345678");
    $this->click("name=login");
    $this->waitForPageToLoad("30000");
    $this->click("link=Events");
    $this->waitForPageToLoad("30000");
    $this->click("//div[@id='eventbox']/div/div/div/a/i");
    $this->waitForPageToLoad("30000");
    $this->click("link=Home");
    $this->waitForPageToLoad("30000");
    $this->click("link=Logout");
    $this->waitForPageToLoad("30000");
    $this->click("link=Login");
    $this->type("id=username", "com2");
    $this->type("id=password", "12345678");
    $this->click("name=login");
    $this->waitForPageToLoad("30000");
    $this->click("link=Update");
    $this->waitForPageToLoad("30000");
    $this->type("name=title", "HEALING THROUGH ARTddqta");
    $this->click("css=input[name=\"Update event\"]");
    $this->waitForPageToLoad("30000");
    $this->click("link=Update");
    $this->waitForPageToLoad("30000");
    $this->type("name=title", "HEALING THROUGH ARTddqt");
    $this->click("css=input[name=\"Update event\"]");
    $this->waitForPageToLoad("30000");
    $this->click("link=New event add /");
    $this->waitForPageToLoad("30000");
    $this->click("xpath=(//a[contains(text(),'Delete')])[2]");
    $this->waitForPageToLoad("30000");
    $this->click("link=Logout/");
    $this->waitForPageToLoad("30000");
    $this->click("css=span.glyphicon.glyphicon-user");
    $this->type("id=username", "test3");
    $this->type("id=password", "1234678");
    $this->click("name=login");
    $this->waitForPageToLoad("30000");
    $this->type("id=username", "test3");
    $this->type("id=password", "12345678");
    $this->click("name=login");
    $this->waitForPageToLoad("30000");
    $this->click("link=Events");
    $this->waitForPageToLoad("30000");
    $this->click("link=Logout");
    $this->waitForPageToLoad("30000");
  }
}
?>