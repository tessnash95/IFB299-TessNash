<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: Story7testS
File Version:1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: Story represent that when a member
signs up for an event. An email is sent to confirm whether 
the user will be there at attendance.

--------------------------------------------------------->
<?php
class Example extends PHPUnit_Extensions_SeleniumTestCase
{
  protected function setUp()
  {
    $this->setBrowser("*chrome");
    $this->setBrowserUrl("http://54.206.25.253/");
  }

  public function testMyTestCase()
  {
    $this->open("/pages/index.php");
    $this->click("link=Login");
    $this->type("id=username", "admintest");
    $this->type("id=password", "12345678");
    $this->click("name=login");
    $this->waitForPageToLoad("30000");
    $this->click("link=member infomation /");
    $this->waitForPageToLoad("30000");
    $this->click("xpath=(//a[contains(text(),'Delete')])[5]");
    $this->assertTrue((bool)preg_match('/^Are you sure you want to delete this member[\s\S]$/',$this->getConfirmation()));
    $this->click("xpath=(//a[contains(text(),'Delete')])[4]");
    $this->assertTrue((bool)preg_match('/^Are you sure you want to delete this member[\s\S]$/',$this->getConfirmation()));
    $this->click("link=Logout/");
    $this->waitForPageToLoad("30000");
  }
}
?>
