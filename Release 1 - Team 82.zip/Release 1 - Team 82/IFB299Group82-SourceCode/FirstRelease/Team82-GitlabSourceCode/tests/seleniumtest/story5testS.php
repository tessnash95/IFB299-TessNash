<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: Story5testS
File Version:1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: Members of the company in all roles
should be able to change the password for their respective 
account at any time.

--------------------------------------------------------->
<?php
class Example extends PHPUnit_Extensions_SeleniumTestCase
{
  protected function setUp()
  {
    $this->setBrowser("*chrome");
    $this->setBrowserUrl("http://gitlab.localhost/community3/community/pages/index.php");
  }

  public function testMyTestCase()
  {
    $this->open("/community3/community/pages/index.php");
    $this->click("link=Login");
    $this->type("id=username", "admin");
    $this->type("id=password", "12345678");
    $this->click("name=login");
    $this->waitForPageToLoad("30000");
    $this->click("link=My Account");
    $this->waitForPageToLoad("30000");
    $this->type("xpath=(//input[@name='password'])[2]", "community82");
    $this->click("name=passwordupdate");
    $this->waitForPageToLoad("30000");
    $this->click("link=Logout");
    $this->waitForPageToLoad("30000");
    $this->click("link=Login");
    $this->type("id=username", "admin");
    $this->type("id=password", "community82");
    $this->click("name=login");
    $this->waitForPageToLoad("30000");
    $this->click("link=My Account");
    $this->waitForPageToLoad("30000");
    $this->type("xpath=(//input[@name='password'])[2]", "12345678");
    $this->click("name=passwordupdate");
    $this->waitForPageToLoad("30000");
    $this->click("link=Logout");
    $this->waitForPageToLoad("30000");
  }
}
?>