<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: Story11testS
File Version:1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: That all features of the website 
can be easily accessed for the user accessing the website.
This should be done through an intuitive navigation bar 
and noticeable hyperlinks.

--------------------------------------------------------->

<?php
class Example extends PHPUnit_Extensions_SeleniumTestCase
{
	protected function setUp()
	{
		$this->setBrowser("*chrome");
		$this->setBrowserUrl("http://gitlab.localhost/community3/community/pages/index.php");
	}

	public function testMyTestCase()
	{
		$this->open("/community4/FirstRelease/sorcecode/pages/index.php");
		$this->click("link=Home");
		$this->waitForPageToLoad("30000");
		$this->click("link=About");
		$this->waitForPageToLoad("30000");
		$this->click("link=Events");
		$this->waitForPageToLoad("30000");
		$this->click("link=Volunteer");
		$this->waitForPageToLoad("30000");
		$this->click("link=Contact");
		$this->waitForPageToLoad("30000");
		$this->click("link=Contact");
		$this->waitForPageToLoad("30000");
		$this->click("//div[@id='myNavbar']/ul[2]/li/a");
	}
}
?>