<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: Story10testS
File Version:1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: Members of the charity can access 
details for their account.

--------------------------------------------------------->

<?php
class Example extends PHPUnit_Extensions_SeleniumTestCase
{
  protected function setUp()
  {
    $this->setBrowser("*chrome");
    $this->setBrowserUrl("http://54.206.25.253/");
  }

  public function testMyTestCase()
  {
    $this->open("/pages/index.php");
    $this->click("link=Login");
    $this->type("id=username", "test3");
    $this->type("id=password", "12345678");
    $this->click("name=login");
    $this->waitForPageToLoad("30000");
    $this->open("admin/membermanage.php");
    $this->click("link=Logout");
    $this->waitForPageToLoad("30000");
    $this->click("link=Login");
    $this->type("id=username", "vol1");
    $this->type("id=password", "12345678");
    $this->click("name=login");
    $this->waitForPageToLoad("30000");
    $this->open("admin/membermanage.php");
    $this->click("link=Logout");
    $this->waitForPageToLoad("30000");
    $this->click("link=Login");
    $this->type("id=username", "com2");
    $this->type("id=password", "12345678");
    $this->click("name=login");
    $this->waitForPageToLoad("30000");
    $this->open("admin/membermanage.php");
    $this->click("link=admin login");
    $this->waitForPageToLoad("30000");
    $this->type("css=div.login > form > div > #username", "admintest");
    $this->type("xpath=(//input[@id='password'])[2]", "12345678");
    $this->click("xpath=(//input[@name='login'])[2]");
    $this->waitForPageToLoad("30000");
    $this->click("link=member infomation /");
    $this->waitForPageToLoad("30000");
    $this->click("link=Logout/");
    $this->waitForPageToLoad("30000");
  }
}
?>