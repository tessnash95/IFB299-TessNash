<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: Story4testS
File Version:1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: All members involved within the 
company should be able to update their data all times. 

--------------------------------------------------------->
<?php
class Example extends PHPUnit_Extensions_SeleniumTestCase
{
  protected function setUp()
  {
    $this->setBrowser("*chrome");
    $this->setBrowserUrl("http://54.206.25.253/");
  }

  public function testMyTestCase()
  {
    $this->open("/pages/index.php");
    $this->click("link=Login");
    $this->type("id=username", "vol1");
    $this->type("id=password", "12345678");
    $this->click("name=login");
    $this->waitForPageToLoad("30000");
    $this->click("link=update my details");
    $this->waitForPageToLoad("30000");
    $this->type("name=lastname", "CHOI12");
    $this->click("name=accountupdate");
    $this->waitForPageToLoad("30000");
    $this->click("link=update my details");
    $this->waitForPageToLoad("30000");
    $this->type("name=lastname", "CHOI1");
    $this->click("name=accountupdate");
    $this->waitForPageToLoad("30000");
    $this->click("link=Logout");
    $this->waitForPageToLoad("30000");
  }
}
?>