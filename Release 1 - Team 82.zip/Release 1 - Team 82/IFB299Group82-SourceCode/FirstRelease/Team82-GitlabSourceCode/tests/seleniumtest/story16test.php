<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: Story16test
File Version:1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: That all features of the website 
can be easily accessed for the user accessing the website.
This should be done through an intuitive navigation bar 
and noticeable hyperlinks.

--------------------------------------------------------->

<?php
class Example extends PHPUnit_Extensions_SeleniumTestCase
{
  protected function setUp()
  {
    $this->setBrowser("*chrome");
    $this->setBrowserUrl("http://54.206.25.253/");
  }

  public function testMyTestCase()
  {
    $this->open("/pages/index.php");
    $this->click("link=Join us");
    $this->waitForPageToLoad("30000");
    $this->click("link=APPLY NOW");
    $this->waitForPageToLoad("30000");
    $this->type("css=#regform > form > input[name=\"username\"]", "new2");
    $this->type("css=form > input[name=\"password\"]", "12345678");
    $this->type("name=firstname", "cool");
    $this->type("name=lastname", "cucumbers");
    $this->type("name=phone", "12");
    $this->type("name=mobile", "12");
    $this->type("css=#regform > form > input[name=\"email\"]", "community82qut@gmail.com");
    $this->select("name=gender", "label=Female");
    $this->click("name=registration");
    $this->waitForPageToLoad("30000");
    $this->click("link=Events");
    $this->waitForPageToLoad("30000");
    $this->click("link=More details");
    $this->waitForPageToLoad("30000");
    $this->click("link=JOIN US");
    $this->waitForPageToLoad("30000");
    $this->type("name=firstname", "cats");
    $this->type("name=lastname", "cucumbers");
    $this->type("name=phone", "12");
    $this->type("name=mobile", "12");
    $this->type("css=#regform > form > input[name=\"email\"]", "community82qut@gmail.com");
    $this->type("xpath=(//input[@name='lastname'])[2]", "head cat");
    $this->type("xpath=(//input[@name='lastname'])[3]", "11111 is fravourite number");
    $this->click("name=registration");
    $this->waitForPageToLoad("30000");
    $this->click("link=Home");
    $this->waitForPageToLoad("30000");
    $this->click("link=Login");
    $this->click("id=myModal");
    $this->click("link=Join us");
    $this->waitForPageToLoad("30000");
    $this->click("xpath=(//a[@type='button'])[2]");
    $this->waitForPageToLoad("30000");
    $this->type("css=#regform > form > input[name=\"username\"]", "unknown1");
    $this->type("css=form > input[name=\"password\"]", "12345678");
    $this->type("name=firstname", "cast");
    $this->type("name=lastname", "bananas");
    $this->type("name=streetnum", "12");
    $this->type("name=streetname", "a street name");
    $this->type("name=suburb", "suburb");
    $this->select("name=state", "label=WA");
    $this->type("name=postcode", "1120");
    $this->type("name=country", "Australia");
    $this->type("name=phone", "12");
    $this->type("name=mobile", "12");
    $this->type("css=#regform > form > input[name=\"email\"]", "community82qut@gmail.com");
    $this->select("name=gender", "label=Male");
    $this->click("name=registration");
    $this->waitForPageToLoad("30000");
    $this->type("css=div.login > form > div > #username", "unknown1");
    $this->type("xpath=(//input[@id='password'])[2]", "12345678");
    $this->click("xpath=(//input[@name='login'])[2]");
    $this->waitForPageToLoad("30000");
    $this->click("link=Events");
    $this->waitForPageToLoad("30000");
    $this->click("//div[@id='eventbox']/div/div/div/a/i");
    $this->waitForPageToLoad("30000");
    $this->click("link=JOIN US");
    $this->waitForPageToLoad("30000");
    $this->type("name=firstname", "est");
    $this->type("name=lastname", "asdf");
    $this->type("name=phone", "123");
    $this->type("name=mobile", "123");
    $this->type("css=#regform > form > input[name=\"email\"]", "community82qut@gmail.com");
    $this->type("xpath=(//input[@name='lastname'])[2]", "head cat");
    $this->type("xpath=(//input[@name='lastname'])[3]", "cats are an issue");
    $this->click("name=registration");
    $this->waitForPageToLoad("30000");
    $this->click("link=My Account");
    $this->waitForPageToLoad("30000");
    $this->click("link=update my details");
    $this->waitForPageToLoad("30000");
    $this->type("name=streetname", "no street for you");
    $this->click("name=accountupdate");
    $this->waitForPageToLoad("30000");
    $this->click("link=Logout");
    $this->waitForPageToLoad("30000");
    $this->click("link=admin login");
    $this->waitForPageToLoad("30000");
    $this->type("css=div.login > form > div > #username", "admintest");
    $this->type("xpath=(//input[@id='password'])[2]", "12345678");
    $this->click("xpath=(//input[@name='login'])[2]");
    $this->waitForPageToLoad("30000");
    $this->click("link=member infomation /");
    $this->waitForPageToLoad("30000");
    $this->click("link=Logout/");
    $this->waitForPageToLoad("30000");
  }
}
?>