<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: Story23test
File Version:1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: That user information is protected 
from other users from altering their information and that 
administration can alter information that does not breach 
the Privacy Act 1998. 

--------------------------------------------------------->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head profile="http://selenium-ide.openqa.org/profiles/test-case">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="selenium.base" href="http://54.206.25.253/" />
<title>story6testS2</title>
</head>
<body>
<table cellpadding="1" cellspacing="1" border="1">
<thead>
<tr><td rowspan="1" colspan="3">story6testS2</td></tr>
</thead><tbody>
<tr>
	<td>open</td>
	<td>pages/index.php</td>
	<td></td>
</tr>
<tr>
	<td>clickAndWait</td>
	<td>link=admin login</td>
	<td></td>
</tr>
<tr>
	<td>type</td>
	<td>css=div.login &gt; form &gt; div &gt; #username</td>
	<td>admintest</td>
</tr>
<tr>
	<td>type</td>
	<td>xpath=(//input[@id='password'])[2]</td>
	<td>12345678</td>
</tr>
<tr>
	<td>clickAndWait</td>
	<td>xpath=(//input[@name='login'])[2]</td>
	<td></td>
</tr>
<tr>
	<td>clickAndWait</td>
	<td>link=member infomation /</td>
	<td></td>
</tr>
<tr>
	<td>clickAndWait</td>
	<td>link=Update</td>
	<td></td>
</tr>
<tr>
	<td>type</td>
	<td>name=contactnumber</td>
	<td>1234</td>
</tr>
<tr>
	<td>clickAndWait</td>
	<td>name=memberupdate</td>
	<td></td>
</tr>
<tr>
	<td>clickAndWait</td>
	<td>link=Update</td>
	<td></td>
</tr>
<tr>
	<td>type</td>
	<td>name=contactnumber</td>
	<td>12</td>
</tr>
<tr>
	<td>clickAndWait</td>
	<td>name=memberupdate</td>
	<td></td>
</tr>
<tr>
	<td>clickAndWait</td>
	<td>link=Logout/</td>
	<td></td>
</tr>

</tbody></table>
</body>
</html>
