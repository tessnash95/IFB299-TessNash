README

You need to have phpUnit with which ever IDE that you use in the libraries and with pear or composer. 
You also need to open the htmls in seleniumhtmltest in moximilla firefox with the tool of selenium installed.
Although it would be prefered that the phpUnit selenium extension should be used to run this test if they do not 
work use the html backups.