<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: Story4test
File Version: 1.0.1 (Release.ConfirmedVersion.CurrentVersion) 
Author: Kris Kingston


---------------------------------------------------------
				Updates
None	

---------------------------------------------------------

Description of the page: All members involved within the
company should be able to update their data all times.

--------------------------------------------------------->

<?php
use PHPUnit_Framework_TestCase;
require_once 'PHPUnit/Autoload.php';

/*
 * Description: Genererates a randomly generated string that at defualt starts at 10
 * 
 * input: $length is the string size to be randomly generated where the default is 
 * 		  set to 10
 * output: $randomString is the randomly generated string by the length of $length
 * 
 * */
function generateRandomString($length = 10) {
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}

/*
 * Description: this is the function to establish a connection to the mysql database
 * 
 * output: returns the mysqli construct as an established connection
 * 
 * */
function setUp()
{
	
	$con = mysqli_connect("localhost", "EventAdmin", "password123", "community");
	
	if (mysqli_connect_errno($con))
	{
		echo "Unable to connect to the server: " . mysqli_connect_error();
		exit();
	}
	
	return $con;
}

class story4test extends \PHPUnit_Framework_TestCase
{
	/* 
	 * Description: Check if connection is capable
	 * 
	 * */
	/** @test */
	public function getConnection()
	{
		echo "getting connection\n";
		
		$con = setUp();
		
		if ($con->connect_error) {
	    $this->assertTrue(false);
		}
		else{$this->assertTrue(true);}
	}

	/* 
	 * Description: check if the getting a row is possible
	 * 
	 * */
	/** @test */
	public function getARow()
	{
		echo "find a row\n";
		
		$con = setUp();
		
		$sql = "SELECT * FROM member";
		
		$result = mysqli_query($con, $sql) or die(mysqli_error($con));
		
		$row = mysqli_fetch_array($result);
		
		$this->assertNotNull($row);

		
	}
	
	/* 
	 * Description: Checks if the User table exists
	 * 
	 *  */
	/** @test */
	public function verifyUserTablesExistMember(){
	
		echo "verifiying if user table exists\n";
	
		$con = setUp();
	
		$sql = "SELECT table_name FROM information_schema.tables where table_schema='community' AND table_name='member';";
	
		$result = mysqli_query($con, $sql) or die(mysqli_error($con));
	
		if($result->num_rows == 1) {
			$this->assertTrue(true);
		}
		else {
			$this->assertTrue(false);
		}
	
	}
	
	/*
	 * Description: Checks if the User table exists
	 *
	 *  */
	/** @test */
	public function verifyUserTablesExistAdmin()
	{
		echo "verifying if admin table exists\n";
	
		$con = setUp();
	
		$sql = "SELECT table_name FROM information_schema.tables where table_schema='community' AND table_name='admin';";
	
		$result = mysqli_query($con, $sql) or die(mysqli_error($con));
	
		if($result->num_rows == 1) {
			$this->assertTrue(true);
		}
		else {
			$this->assertTrue(false);
		}
	
	}
	
	/*
	 * Description: Checks if the User table exists
	 *
	 *  */
	/** @test */
	public function verifyUserTablesExistVolunteer()
	{
		echo "verifying the Volunteer table\n";
	
				$con = setUp();
	
				$sql = "SELECT table_name FROM information_schema.tables where table_schema='community' AND table_name='volunteer';";
	
				$result = mysqli_query($con, $sql) or die(mysqli_error($con));
	
				if($result->num_rows == 1) {
					$this->assertTrue(true);
				}
				else {
					$this->assertTrue(false);
				}
	}
	
	/*
	 * Description: Checks if the user table can be updated
	 *
	 *  */
	/** @test */
	public function UpdateUserDetails()
	{
		echo "verifying the details can be updated table\n";
		
		$con = setUp();
		
		$queryLastName = "SELECT lastname FROM member ORDER BY lastname DESC LIMIT 1;";
		
		$originalResult = mysqli_query($con, $queryLastName) or die(mysqli_error($con));
		
		$row1 = mysqli_fetch_array($originalResult);
		
		$g = $row1[0];
		
		echo "Last Name of the user that will have their first name changed: ";
		
		echo "'$row1[0]'\n";
		
 		$newName = generateRandomString();
 		
 		echo "randomly generated string: ";
		
		echo "'$newName'\n";
		
		$queryAlterTableFirstName = "UPDATE member SET firstname='$newName'  WHERE lastname='$g';";
		
		mysqli_query($con, $queryAlterTableFirstName) or die(mysqli_error($con));
		
		$queryLastName2 = "SELECT firstName FROM member WHERE firstname= '$newName';";
		
		$newResult = mysqli_query($con, $queryLastName2) or die(mysqli_error($con));
		
		$row2 = mysqli_fetch_array($newResult);
		
		echo "string in the firstname column: ";
		
		echo "'$row2[0]'\n";
		
		$this->assertSame($row2[0], $newName); 
		
	}

}