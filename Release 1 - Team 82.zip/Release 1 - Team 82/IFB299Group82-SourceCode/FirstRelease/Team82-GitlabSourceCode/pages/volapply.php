<?php
	$page = "Registration";
	include '../includes/connect.php';
	include '../includes/header.php'; //session_start(); included in header.php
  include '../includes/nav.php';
?>
	<div class="login">
	<div id="regform">
  <?php
    $sql = "SELECT * FROM events WHERE eventID =" . $_GET['eventID'];
    $result = mysqli_query($con, $sql) or die(mysqli_error($con));
    $row = mysqli_fetch_array($result);
    $pageTitle = $row['title'];?>
		<hr><h2>volunteer the event application form<hr>
      <?php echo 'Event :' .$pageTitle;?></h2>

<?php
	//user messages
	if (isset($_SESSION['error']))
	{
		echo'<div class="error">';
		echo'<p>' . $_SESSION['error'] . '</p>';
		echo'</div>';
		unset($_SESSION['error']);
	}
?>
	<form action="voleventprocessiong.php" method="post" enctype="multipart/form-data"> <!-- the multipart/form-data is essential for file upload functionality -->
	<label>First Name*</label> <input type="text" name="firstname" required /><br />
	<label>Last Name*</label> <input type="text" name="lastname" required /><br/>
	<label>Phone</label> <input type="text" name="phone" /><br />
	<label>Mobile</label> <input type="text" name="mobile" /><br />
	<label>Email*</label> <input type="email" name="email"/><br />
	<label>Position</label> <input type="text" name="lastname" /><br/>
  <label>comment</label> <input type="text" name="lastname" /><br/>
  <p><input type="submit" name="registration" value="Appy"/></p>
</form>
</div>
