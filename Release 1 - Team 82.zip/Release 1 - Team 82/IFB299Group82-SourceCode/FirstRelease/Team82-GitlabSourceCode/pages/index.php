<!-------------------------------------------------------

Subject: IFB299		Group: Group 82
Webpage: index.php(pages directory)
File Version: 1.0.2 (Release.ConfirmedVersion.CurrentVersion) 
Author: Ji-Young Choi


---------------------------------------------------------
				Updates
Version: 1.0.1 (Ji-Young Choi)

Intial Issue

Version: 1.0.2 (Se Jun Ahn)

Formatting page.

---------------------------------------------------------

Description of the page: index page that homepage include navigations with upcmoing events and urgent.

--------------------------------------------------------->

<?php
 $page = "Home";
 include "../includes/connect.php";
 include '../includes/header.php';
 include '../includes/imgslide.php';
 include '../includes/nav.php';
 include '../includes/urgentcause.php';
?>

<?php
 include '../includes/footer.php';
?>
