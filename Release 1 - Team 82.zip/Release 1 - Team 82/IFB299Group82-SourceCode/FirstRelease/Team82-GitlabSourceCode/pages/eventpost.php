<?php
$page = "eventpost";
include '../includes/connect.php';
include '../includes/header.php';
include '../includes/nav.php';


?>
<div class="container">
  <div class="row">
    <div class="col-md-10">
    <hr><h1 float="left" >OUR <strong>EVENTS </h1><hr></div>
  </div>
<div class="row">

 <?php
 $sql = "SELECT * FROM events WHERE eventID =" . $_GET['eventID'];
 $result = mysqli_query($con, $sql) or die(mysqli_error($con));
 $row = mysqli_fetch_array($result);
 $pageTitle = $row['title'];

?>
</div>
<div class="row" >
  <div class="col-md-8">
<div class='img-responsive'><img src='../img/test4.jpg'></div><div class="col-md-pull-1"><span class="eventdatebtn" >24 Sep </button></div><div class='col-md-push-3'><h1>WATER OF LIFE</h1>1:00 pm  </div><br><div class='col-md-pull-8 card'><h3> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</h3><br/><h3>Botanic garden</h3> <a href="volapply.php?eventID=4" type="button" class="btn btn-default btn-lg pull-right postbtn"> <span class="glyphicon glyphicon-triangle-right"
  aria-hidden="true"></span>JOIN US</strong></a></div>
    
</div>


<div class="col-md-4 text-center" >
<div class="makedonation" style="border:5px solid #003169; ">
<h3>MAKE A DONATION</h3>
</div>
<div class="row card">
  <div class="row "style="background-color:#022C37; margin:10px 0;"><div class="eventcardtxt1 pull-left text-center"><h5>WATER OF LIFE</h5><hr><h5>2016-09-24 13:00</h5><p>Botanic garden</p><a href="eventpost.php?eventID=4" type="button" class="btn btn-primary-outline event"><i>More details</i></a></div><div class='pull-right'><img src='../img/test4.jpg'style='width:150px; height:200px;' background-size='cover'></div></div><div class="row "style="background-color:#022C37; margin:10px 0;"><div class="eventcardtxt1 pull-left text-center"><h5>HEALING THROUGH ARTddqt</h5><hr><h5>2016-09-30 10:00</h5><p>QUTd</p><a href="eventpost.php?eventID=3" type="button" class="btn btn-primary-outline event"><i>More details</i></a></div><div class='pull-right'><img src='../img/test1.jpg'style='width:150px; height:200px;' background-size='cover'></div></div></div>
      </div>
      
      
      <div class="col-md-pull-1"><span class="eventdatebtn1">venue</span></div>
      <div class="row col-md-4 card pull-right">
        <h3>Botanic garden</h3> <iframe id="map" width="100%" height="90%" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" src="https://maps.google.com/maps?f=q&source=s_q&hl=en&geocode=&ie=UTF8&iwloc=A&output=embed&z=6&q=brisbane"></iframe>
      </div>
      </div>
      </div>
      
      
      
      <footer class="footer navbar-fixed-bottom">
      
      &copy; copyright&nbsp;&#9615; WEBSITE BY community82 2016
      <a href= "../admin/adminlogin.php">admin login</a>
      
      </footer>
      </body>
      
      
      </html>

<?php
 include "../includes/footer.php";
?>
