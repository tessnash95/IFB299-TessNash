<?php
	session_start();
	include "../includes/connect.php";
?>
<?php
	$username = mysqli_real_escape_string($con, $_POST['username']); //prevent SQL injection
	$password = mysqli_real_escape_string($con, $_POST['password']);
	$firstName = mysqli_real_escape_string($con, $_POST['firstname']);
	$lastName = mysqli_real_escape_string($con, $_POST['lastname']);
$streetnum = mysqli_real_escape_string($con, $_POST['streetnum']);
	$streetname= mysqli_real_escape_string($con, $_POST['streetname']);
	$suburb = mysqli_real_escape_string($con, $_POST['suburb']);
	$state = mysqli_real_escape_string($con, $_POST['state']);
	$postcode = mysqli_real_escape_string($con, $_POST['postcode']);
	$country = mysqli_real_escape_string($con, $_POST['country']);
	$phone = mysqli_real_escape_string($con, $_POST['phone']);
	$mobile = mysqli_real_escape_string($con, $_POST['mobile']);
	$email = mysqli_real_escape_string($con, $_POST['email']);
	$gender = mysqli_real_escape_string($con, $_POST['gender']);
	$newsletter = mysqli_real_escape_string($con, $_POST['newsletter']);

 if($_FILES['image']['name']) //if an image has been uploaded
 {

	$image = $_FILES['image']['name']; //the PHP file upload variable for a file

	$randomDigit = rand(0000,9999); //generate a random numerical digit <= 4 characters

	$newImageName = strtolower($randomDigit . "_" . $image); //attach the random digit to the front of uploaded images to prevent overriding files with the same name in the images folder and enhance security
 $target = "../images/" . $newImageName; //the target for uploaded images
 $allowedExts = array('jpg', 'jpeg', 'gif', 'png'); //create an array with the allowed file extensions
 $tmp = explode('.', $_FILES['image']['name']); //split the file name from the file extension
 $extension = end($tmp); //retrieve the extension of the photo e.g., png

 if($_FILES['image']['size'] > 512000) //image maximum size is 500kb
 {
 $_SESSION['error'] = 'Your file size exceeds maximum of 500kb.'; //if file exceeds max size intialise a session called 'error' with a msg
 header("location:registration.php"); //redirect to registration.php
 exit();
 }
 elseif(($_FILES['image']['type'] == 'image/jpg') || ($_FILES['image']['type']
== 'image/jpeg') || ($_FILES['image']['type'] == 'image/gif') ||
($_FILES['image']['type'] == 'image/png') && in_array($extension, $allowedExts))
 {
 move_uploaded_file($_FILES['image']['tmp_name'], $target); //move the image to images folder
 }
 else
 {
 $_SESSION['error'] = 'Only JPG, GIF and PNG files allowed.'; //if file uses an invalid extension intialise a session called 'error' with a msg
 header("location:registration.php"); //redirect to registration.php
 exit();
 }

 }

 if (strlen($password) < 8) //check if the password is a minimum of 8 characters long
 {
 $_SESSION['error'] = 'Password must be 8 characters or more.'; //if password is less than 8 characters intialise a session called 'error' with a msg
 header("location:registration.php"); //redirect to registration.php
 exit();
 }

 $salt = md5(uniqid(rand(), true)); //create a random salt value
 $password = hash('sha256', $password.$salt); //generate the hashed password with the salt value

 $sql = "(SELECT username FROM member WHERE member.username='$username') UNION
(SELECT username FROM admin WHERE admin.username='$username')"; //check if the username is taken in the member table or the admin table as the username must be unique
 $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
 $numrow = mysqli_num_rows($result); //count how many rows are returned

 if($numrow > 0) //if count greater than 0
 {
 $_SESSION['error'] = 'Username taken. Please retry.'; //if an username is taken intialise a session called 'error' with a msg
 header("location:registration.php"); //redirect to registration.php
 exit();
 }
 elseif ($username == "" || $password == "" || $firstName == "" || $lastName == ""
|| $postcode == "" || $country =="" || $email == "" || $gender == "" || $newsletter ==
"") //check if all required fields have data

{
 $_SESSION['error'] = 'All * fields are required.'; //if an error occurs intialise a session called 'error' with a msg
 header("location:registration.php"); //redirect to registration.php
 exit();
 }
 elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) //check if email is valid
 {
 $_SESSION['error'] = 'Please enter a valid email address.'; //if an error occurs intialise a session called 'error' with a msg
 header("location:registration.php"); //redirect to registration.php
 exit();
 }
 else
 {
 $sql="INSERT INTO member (username, password, salt, firstname, lastname, streetnum, streetname, suburb, state, postcode, country, phone, mobile, email, gender, date,
newsletter, image, type) VALUES ('$username', '$password', '$salt', '$firstName',
'$lastName', '$streetnum', '$streetname', '$suburb', '$state', '$postcode', '$country', '$phone',
'$mobile', '$email', '$gender', NOW(), '$newsletter', '$newImageName', '1')";
 $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

 $_SESSION['success'] = 'You created a new account. Please login'; //if registration is successful intialise a session called 'success' with a msg
 header("location:login.php"); //redirect to login.php
 }

?>
