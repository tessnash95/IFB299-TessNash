<?php
 $page = "Loginchoice";

 include '../includes/connect.php';
 include '../includes/header.php';
 include '../includes/nav.php';
?>
<div class="con">
<div class="container-fluid text-center bg-grey "style="padding:10%;" >

 <hr><h1 style="color:grey">GET <strong>INVOLVED</strong></h1><hr>
 <div class="col-xs-6 .col-md-4" >

   <div class="thumbnail" ><p class=" text-center"><span style="font-size:1.8em; ">BECOME A<br> <strong>VOLUNTEER</span></strong><br>
     </p>
     <img src="../img/donation1.jpg" alt="Paris" width="230" height="200"  >

   </div><a href="volregi.php" type="button" class="btn btn-default boxbtn1"> <span class="glyphicon glyphicon-triangle-right" aria-hidden="true"></span>APPLY NOW</button>
 </a></div>
 <div class="col-xs-6 .col-md-4">

   <div class="thumbnail"><p class=" text-center"><span style="font-size:1.8em;">SIGN UP AS<br> <strong>MEMBER </span></strong><br>
  </p>
     <img src="../img/donation1.jpg" alt="Paris" width="230" height="200">

   </div><a href="registration.php" type="button" class="btn btn-default boxbtn1"> <span class="glyphicon glyphicon-triangle-right" aria-hidden="true"></span>APPLY NOW</button>
 </a></div>

</div></div>

<?php
 include '../includes/footer.php';
?>
