<?php
 session_start();
 include "../includes/connect.php";
?>
<?php
$memberID = $_POST['memberID'];
$sql = "UPDATE member SET memberdelete= '1' WHERE memberID = $memberID";

 $result = mysqli_query($con, $sql) or die(mysqli_error($con));


 $_SESSION['success'] = 'Account deletion has been applied.';

 header('location: index.php') ;
?>
